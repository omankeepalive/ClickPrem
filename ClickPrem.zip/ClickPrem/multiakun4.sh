#!/bin/bash

clear
echo "\033[1;31m      Multi Akun  "
sleep 1s

echo "\033[1;31m     bersiaplah  kita  akan mulai  "
sleep 2s

python telemaxv7.3.4.py +6285329127958 zec &
python telemaxv7.3.4.py session zec &
python telemaxv7.3.4.py +18634014849 zec &
python telemaxv7.3.4.py +16413288097 zec &
python telemaxv7.3.4.py +19733527647 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 1 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +15872056008 zec &
python telemaxv7.3.4.py +17733575773 zec &
python telemaxv7.3.4.py +13312279516 zec &
python telemaxv7.3.4.py +19163140955 zec &
python telemaxv7.3.4.py +18052224296 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 2 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +16473629439 zec &
python telemaxv7.3.4.py +17786080410 zec &
python telemaxv7.3.4.py +17784031599 zec &
python telemaxv7.3.4.py +17786088280 zec &
python telemaxv7.3.4.py +13346500185 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 3 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +13346007132 zec &
python telemaxv7.3.4.py +17784018440 zec &
python telemaxv7.3.4.py +6285704127092 zec &
python telemaxv7.3.4.py +13343758220 zec &
python telemaxv7.3.4.py +13342180846 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 4 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +13344527511 zec &
python telemaxv7.3.4.py +13345912613 zec &
python telemaxv7.3.4.py +12513208644 zec &
python telemaxv7.3.4.py +18722558919 zec &
python telemaxv7.3.4.py +17573173696 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 5 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +6285842160158 zec &
python telemaxv7.3.4.py +6285727078421 zec &
python telemaxv7.3.4.py +18283919261 zec &
python telemaxv7.3.4.py +19083003899 zec &
python telemaxv7.3.4.py +17786080782 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 6 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +17784016874 zec &
python telemaxv7.3.4.py +14155980947 zec &
python telemaxv7.3.4.py +13344563708 zec &
python telemaxv7.3.4.py +13364389289 zec &
python telemaxv7.3.4.py +13345958788 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 7 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +13414449699 zec &
python telemaxv7.3.4.py +18042201527 zec &
python telemaxv7.3.4.py +12252459266 zec &
python telemaxv7.3.4.py +14402092769 zec &
python telemaxv7.3.4.py +16784339858 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 8 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +14153493812 zec &
python telemaxv7.3.4.py +18024005086 zec &
python telemaxv7.3.4.py +13345686436 zec &
python telemaxv7.3.4.py +13345686664 zec &
python telemaxv7.3.4.py +13345805642 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 9 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +13345770793 zec &
python telemaxv7.3.4.py +13344722990 zec &
python telemaxv7.3.4.py +13346073575 zec &
python telemaxv7.3.4.py +13345230144 zec &
python telemaxv7.3.4.py +13346072567 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 10 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +13346072446 zec &
python telemaxv7.3.4.py +13346072617 zec &
python telemaxv7.3.4.py +18023686185 zec &
python telemaxv7.3.4.py +13372234413 zec &
python telemaxv7.3.4.py +14434907567 zec &

x=1200
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m [ 11 ] ke 5 akun lagi sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done

python telemaxv7.3.4.py +14433801486 zec &
python telemaxv7.3.4.py +6281262553656 zec &
python telemaxv7.3.4.py +13343393838 zec &
python telemaxv7.3.4.py +12672772573 zec &
python telemaxv7.3.4.py +6287733441831 zec &

x=12000
while [ $x -gt 0 ]
do
sleep 20s
clear
echo " \033[1;36m lanjut ke Multi  clickbot sisa Waktu anda $x Detik"
x=$(( $x - 20 ))
done
cd /$HOME/telebot
sh multiakun.sh
done
